﻿using CleanArchitectureCosmosDB.Core.Entities;

namespace CleanArchitectureCosmosDB.Core.Interfaces
{
    public interface IToDoItemRepository : IRepository<ToDoItem>
    {
    }
}
